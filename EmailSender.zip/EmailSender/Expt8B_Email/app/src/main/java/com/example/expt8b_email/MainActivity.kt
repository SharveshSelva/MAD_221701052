package com.example.expt8b_email

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etMessage: EditText
    private lateinit var btnSendEmail: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the views
        etEmail = findViewById(R.id.etEmail)
        etMessage = findViewById(R.id.etMessage)
        btnSendEmail = findViewById(R.id.btnSendEmail)

        // Set onClickListener to the send email button
        btnSendEmail.setOnClickListener {
            val email = etEmail.text.toString()
            val message = etMessage.text.toString()

            // Check if email and message are not empty
            if (email.isNotEmpty() && message.isNotEmpty()) {
                sendEmail(email, message)
            } else {
                // If email or message is empty, display a toast or other UI feedback
                // Toast.makeText(this, "Please enter both email and message", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendEmail(email: String, message: String) {
        // Create an intent to send an email
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"  // Email MIME type
            putExtra(Intent.EXTRA_EMAIL, arrayOf(email)) // Recipient's email address
            putExtra(Intent.EXTRA_SUBJECT, "Subject Here")  // Subject of the email (optional)
            putExtra(Intent.EXTRA_TEXT, message)  // Message body
        }

        // Start the email activity
        try {
            startActivity(Intent.createChooser(intent, "Choose an email client"))
        } catch (e: Exception) {
            // Handle case where no email app is available
            // Toast.makeText(this, "No email client installed", Toast.LENGTH_SHORT).show()
        }
    }
}
