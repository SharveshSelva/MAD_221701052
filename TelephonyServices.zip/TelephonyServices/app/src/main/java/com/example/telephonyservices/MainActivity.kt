package com.example.telephonyservices
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var networkOperatorNameTextView: TextView
    private lateinit var phoneTypeTextView: TextView
    private lateinit var networkCountryIsoTextView: TextView
    private lateinit var simCountryIsoTextView: TextView
    private lateinit var deviceSoftwareVersionTextView: TextView
    private lateinit var getServicesButton: Button

    private val TELEPHONY_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        networkOperatorNameTextView = findViewById(R.id.networkOperatorNameTextView)
        phoneTypeTextView = findViewById(R.id.phoneTypeTextView)
        networkCountryIsoTextView = findViewById(R.id.networkCountryIsoTextView)
        simCountryIsoTextView = findViewById(R.id.simCountryIsoTextView)
        deviceSoftwareVersionTextView = findViewById(R.id.deviceSoftwareVersionTextView)
        getServicesButton = findViewById(R.id.getServicesButton)

        // Set click listener for button
        getServicesButton.setOnClickListener {
            checkTelephonyPermission()
        }
    }

    private fun checkTelephonyPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Show permission explanation dialog
            showPermissionDialog()
        } else {
            // Permission already granted, get telephony info
            getTelephonyInfo()
        }
    }

    private fun showPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Allow Telephony Services")
            .setMessage("to make and manage phone calls?")
            .setIcon(R.drawable.ic_phone)
            .setPositiveButton("ALLOW") { _, _ ->
                // Request permission
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_PHONE_STATE),
                    TELEPHONY_PERMISSION_CODE
                )
            }
            .setNegativeButton("DENY") { dialog, _ ->
                dialog.dismiss()
                Toast.makeText(
                    this,
                    "Permission denied. Cannot access telephony services.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .create()
            .show()
    }

    private fun getTelephonyInfo() {
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        // Get network operator name
        val networkOperatorName = if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            telephonyManager.networkOperatorName.ifEmpty { "Android" }
        } else {
            "Permission required"
        }
        networkOperatorNameTextView.text = networkOperatorName

        // Get phone type
        val phoneType = when (telephonyManager.phoneType) {
            TelephonyManager.PHONE_TYPE_GSM -> "GSM"
            TelephonyManager.PHONE_TYPE_CDMA -> "CDMA"
            TelephonyManager.PHONE_TYPE_SIP -> "SIP"
            TelephonyManager.PHONE_TYPE_NONE -> "NONE"
            else -> "UNKNOWN"
        }
        phoneTypeTextView.text = phoneType

        // Get network country ISO
        val networkCountryIso = telephonyManager.networkCountryIso.uppercase().ifEmpty { "US" }
        networkCountryIsoTextView.text = networkCountryIso

        // Get SIM country ISO
        val simCountryIso = telephonyManager.simCountryIso.uppercase().ifEmpty { "US" }
        simCountryIsoTextView.text = simCountryIso

        // Get device software version
        val deviceSoftwareVersion = if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            telephonyManager.deviceSoftwareVersion ?: "---"
        } else {
            "---"
        }
        deviceSoftwareVersionTextView.text = deviceSoftwareVersion

        Toast.makeText(this, "Telephony information updated", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == TELEPHONY_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, get telephony info
                getTelephonyInfo()
            } else {
                Toast.makeText(
                    this,
                    "Permission denied. Cannot access telephony services.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
